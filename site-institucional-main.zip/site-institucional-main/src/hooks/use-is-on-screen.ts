import { useRef, useState, useEffect, RefObject } from "react";

const useIsOnScreen = (ref: RefObject<HTMLElement | null>) => {
  const observerRef = useRef<IntersectionObserver | null>(null);
  const [isOnScreen, setIsOnScreen] = useState(false);

  useEffect(() => {
    observerRef.current = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsOnScreen(true);
      }
    });
  }, []);

  useEffect(() => {
    if (ref?.current && observerRef) {
      observerRef.current?.observe(ref.current);
      return () => {
        observerRef.current?.disconnect();
      };
    }
  }, [ref]);

  return isOnScreen;
};

export default useIsOnScreen;